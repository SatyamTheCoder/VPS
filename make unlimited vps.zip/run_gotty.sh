#!/bin/bash


/usr/local/bin/gotty --permit-write --reconnect /bin/bash
